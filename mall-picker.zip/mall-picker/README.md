# Mall picker

A Pen created on CodePen.io. Original URL: [https://codepen.io/JKamagie/pen/xxvMEdb](https://codepen.io/JKamagie/pen/xxvMEdb).

